package com.example.btl_dbclpm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtlDbclpmApplicationTests {

	@Test
	void contextLoads() {
	}

}
