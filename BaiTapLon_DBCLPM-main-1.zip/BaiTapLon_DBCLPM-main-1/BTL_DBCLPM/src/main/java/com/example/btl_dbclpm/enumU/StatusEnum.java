package com.example.btl_dbclpm.enumU;

public enum StatusEnum {
    WAITING_FOR_INPUT,
    WAITING_FOR_CALCULATION,
    WAITING_FOR_PAYMENT
}
