package com.example.btl_dbclpm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtlDbclpmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtlDbclpmApplication.class, args);
	}

}
