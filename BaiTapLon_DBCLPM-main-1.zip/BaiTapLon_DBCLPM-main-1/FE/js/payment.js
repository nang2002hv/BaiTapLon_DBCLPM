var customer = localStorage.getItem("customer");

console.log(customer);